﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ptriangulo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            int ladoA = int.Parse(txtA.Text);
            int ladoB = int.Parse(txtB.Text);
            int ladoC = int.Parse(txtC.Text);

            if (ladoA < ladoB + ladoC && ladoA > Math.Abs(ladoB - ladoC) &&
                ladoB < ladoA + ladoC && ladoB > Math.Abs(ladoA - ladoC) &&
                ladoC < ladoA + ladoB && ladoC > Math.Abs(ladoA - ladoB))
            {
                string tipoTriangulo;

                if (ladoA == ladoB && ladoB == ladoC)
                {
                    tipoTriangulo = "Equilátero";
                }
                else if (ladoA == ladoB || ladoB == ladoC || ladoA == ladoC)
                {
                    tipoTriangulo = "Isósceles";
                }
                else
                {
                    tipoTriangulo = "Escaleno";
                }

                MessageBox.Show($"Os lados formam um triângulo {tipoTriangulo}.");
            }
            else
            {
                MessageBox.Show("Os lados não formam um triângulo válido.");
            }
        }


        private void txtA_Validated(object sender, EventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(txtA.Text) && !int.TryParse(txtA.Text, out _))
            {
                MessageBox.Show("Por favor, insira um número inteiro válido em A.",
                                "Entrada inválida",
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Error);
                txtA.Focus();
            }
        }

        private void txtB_Validated(object sender, EventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(txtB.Text) && !int.TryParse(txtB.Text, out _))
            {
                MessageBox.Show("Por favor, insira um número inteiro válido em B.",
                                "Entrada inválida",
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Error);
                txtB.Focus();
            }
        }
        private void txtC_Validated(object sender, EventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(txtC.Text) && !int.TryParse(txtC.Text, out _))
            {
                MessageBox.Show("Por favor, insira um número inteiro válido em C.",
                                "Entrada inválida",
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Error);
                txtC.Focus();
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtA.Clear();
            txtB.Clear();
            txtC.Clear();
            txtA.Focus();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}