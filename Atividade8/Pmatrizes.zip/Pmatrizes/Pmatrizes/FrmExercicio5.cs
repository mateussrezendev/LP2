﻿using Microsoft.VisualBasic;
using System;
using System.Windows.Forms;

namespace Pmatrizes
{
    public partial class FrmExercicio5 : Form
    {
        public FrmExercicio5()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            string[,] matriz = new string[6, 10];
            string[] gabarito = { "A", "A", "B", "D", "D", "D", "C", "A", "A", "B" };
            string auxiliar;

            lstbx.Items.Clear();

            for (int i = 0; i < 6; i++)
            {
                for (int j = 0; j < 10; j++)
                {
                    do
                    {
                        auxiliar = Interaction.InputBox(
                            $"Digite a resposta do aluno {i + 1}, questão {j + 1}:","Entrada de dados").ToUpper();

                        if (string.IsNullOrEmpty(auxiliar) || !"ABCDE".Contains(auxiliar))
                        {
                            MessageBox.Show("Dado inválido! Digite uma letra de A a E.");
                        }

                    } while (string.IsNullOrEmpty(auxiliar) || !"ABCDE".Contains(auxiliar));

                    matriz[i, j] = auxiliar;

                    if (auxiliar == gabarito[j])
                        lstbx.Items.Add($"O aluno:{i + 1} acertou a questão:{j + 1} era {gabarito[j]} escolheu {auxiliar}");
                    else
                        lstbx.Items.Add($"O aluno:{i + 1} errou a questão:{j + 1} era {gabarito[j]} escolheu {auxiliar}");
                }
            }
        }
    }
}
