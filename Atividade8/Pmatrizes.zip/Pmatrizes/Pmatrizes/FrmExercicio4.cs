﻿using System;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace Pmatrizes
{
    public partial class FrmExercicio4 : Form
    {
        public FrmExercicio4()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            string[] nomes = new string[10];
            int[] comprimento = new int[10];
            string auxiliar;

            for (int i = 0; i < 10; i++)
            {
                auxiliar = Interaction.InputBox($"Digite o {i + 1}º nome:", "Entrada de dados");

                if (auxiliar == "")
                {
                    MessageBox.Show("Dado inválido!");
                    i--;
                }
                else
                { 
                    nomes[i] = auxiliar;
                    comprimento[i] = auxiliar.Replace(" ", "").Length;
                    lstbxNomes.Items.Add($"o nome:{nomes[i]} tem {comprimento[i]} caracteres\n");
                }
            }

        }
    }
}
