﻿using Microsoft.VisualBasic;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pmatrizes
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnExercicio1_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];
            string auxiliar = "";

            for (int i = 0; i < 20; i++)
            {
                auxiliar = Interaction.InputBox($"Digite o {i + 1}° número", "Entrada de dados");

                if (!int.TryParse(auxiliar, out vetor[i]))
                {
                    MessageBox.Show("Valor inválido");
                    i--;
                }
            }

            Array.Reverse(vetor);
            auxiliar = "";
            auxiliar = string.Join("\n", vetor);
            MessageBox.Show(auxiliar);
        }

        private void btnExercicio2_Click(object sender, EventArgs e)
        {
            ArrayList lista = new 
                ArrayList(){"Ana", "André", "Beatriz", "Camila", "João", "Joana", "Otávio", "Marcelo", "Pedro", "Thais"};
            lista.Remove("Otávio");
            string auxiliar = "";
            foreach (string nome in lista)
                auxiliar += nome + "\n";
            MessageBox.Show(auxiliar);
        }

        private void btnExercicio3_Click(object sender, EventArgs e)
        {
            Double[,] notas = new double[20, 3];
            string auxiliar = "";
            string saida = "";
            double media = 0;

            for(int i = 0; i < 20; i++)
            {
                for(int j = 0; j < 3; j++)
                {
                    auxiliar = Interaction.InputBox($"Digite a nota {j+1} do aluno {i+1}", "Entrada de dados");
                    if (!(Double.TryParse(auxiliar, out notas[i,j]) || notas[i,j] < 0 || notas[i,j] > 10))
                    {
                        MessageBox.Show("Dados inválidos");
                    }
                    else
                    {
                        media += notas[i, j];
                    }
                }
                saida += ($"Aluno {i + 1} - média: {media / 3}\n");
                media = 0;
                MessageBox.Show(saida);
            }

        }

        private void btnExercicio4_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<FrmExercicio4>().Count() > 0)
            {
                Application.OpenForms["FrmExercicio4"].BringToFront();
            }
            else
            {
                FrmExercicio4 Frm4 = new FrmExercicio4();
                Frm4.Show();
            }
        }

        private void btnExercicio5_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<FrmExercicio5>().Count() > 0)
            {
                Application.OpenForms["FrmExercicio5"].BringToFront();
            }
            else
            {
                FrmExercicio5 Frm5 = new FrmExercicio5();
                Frm5.Show();
            }
        }
    }
}
