﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pmetodos
{
    public partial class FrmExercicio5 : Form
    {
        public FrmExercicio5()
        {
            InitializeComponent();
        }

        private void FrmExercicio5_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
        private void btnSortear_Click(object sender, EventArgs e)
        {
            int numero1, numero2;

            if (!int.TryParse(txtNumero1.Text, out numero1) || !int.TryParse(txtNumero2.Text, out numero2))
            {
                MessageBox.Show("Digite apenas números inteiros válidos!", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (numero1 >= numero2)
            {
                MessageBox.Show("O primeiro número deve ser menor que o segundo!", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            Random rnd = new Random();
            int sorteado = rnd.Next(numero1, numero2 + 1);

            MessageBox.Show($"Número sorteado: {sorteado}", "Resultado", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

    }
}
