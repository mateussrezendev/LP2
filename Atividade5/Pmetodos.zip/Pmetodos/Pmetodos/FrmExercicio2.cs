﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pmetodos
{
    public partial class FrmExercicio2 : Form
    {
        public FrmExercicio2()
        {
            InitializeComponent();
        }

        private void BtnInserir_Click(object sender, EventArgs e)
        {
            int meio = TxtPalavra2.Text.Length/2;
            TxtPalavra2.Text = TxtPalavra2.Text.Substring(0, meio) + TxtPalavra1.Text + TxtPalavra2.Text.Substring(meio, TxtPalavra2.Text.Length - meio);
        }

        private void BtnInserir2_Click(object sender, EventArgs e)
        {
            int meio = TxtPalavra1.Text.Length / 2;
            TxtPalavra2.Text = TxtPalavra1.Text.Insert(meio, "**");
        }

        private void BtnVerificar_Click(object sender, EventArgs e)
        {
            string pal1 = TxtPalavra1.Text;
            string pal2 = TxtPalavra2.Text;
            
            if(pal1 == pal2)
            {
                MessageBox.Show("São iguais");
            }
            

        }
    }
}
