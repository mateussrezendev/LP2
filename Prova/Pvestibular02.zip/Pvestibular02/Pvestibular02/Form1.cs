﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace Pvestibular02
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnReceberDados_Click(object sender, EventArgs e)
        {
            double[,] matriz = new double[2, 5];
            double totalCurso = 0, totalGeral = 0;
            string auxiliar;

            for (int i = 0; i < 2; i++)
            {
                totalCurso = 0;
                for (int j = 0; j < 5; j++)
                {
                    do
                    {
                        auxiliar = Interaction.InputBox($"Digite a quantidade de pessoas que realizaram o vestibular para o curso {i + 1} no ano {j + 1}: ", "Entrada de Dados");

                        if (string.IsNullOrEmpty(auxiliar))
                        {
                            MessageBox.Show("Dado inválido! Digite um número inteiro positivo");
                        }

                    } while (string.IsNullOrEmpty(auxiliar));


                    matriz[i, j] = Convert.ToDouble(auxiliar);
                    totalCurso += matriz[i, j];
                    totalGeral += matriz[i, j];

                    if (matriz[i, j] <= 0)
                    {
                        MessageBox.Show("Dado inválido! Digite um número inteiro positivo");
                        j--;
                    }
                    else
                    {
                        lstbox.Items.Add($"Total do curso {i + 1} do Ano {j + 1}: {auxiliar}");
                    }


                }
                lstbox.Items.Add($"Total do curso {i + 1}: {totalCurso}");  
            }
            lstbox.Items.Add($"Total Geral: {totalGeral}");
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            lstbox.Items.Clear();
        }
    }
}
